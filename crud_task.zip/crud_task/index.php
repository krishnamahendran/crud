<?php include( 'server.php'); ?>
<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>CRUD Operations</title>
	<link rel="stylesheet" href="bootstrap-4.0.0/css/bootstrap.min.css">
	<link rel="stylesheet" href="css/style.css">
	<script defer src="https://use.fontawesome.com/releases/v5.0.13/js/solid.js" integrity="sha384-tzzSw1/Vo+0N5UhStP3bvwWPq+uvzCMfrN1fEFe+xBmv1C/AtVX5K0uZtmcHitFZ" crossorigin="anonymous"></script>
	<script defer src="https://use.fontawesome.com/releases/v5.0.13/js/fontawesome.js" integrity="sha384-6OIrr52G08NpOFSZdxxz1xdNSndlD4vdcf/q2myIUVO0VsqaGHJsB0RaBE01VTOY" crossorigin="anonymous"></script>
	
</head>

<body>
	<div class="wrapper">
		<!-- Sidebar  -->
		<nav id="sidebar">
			<div class="sidebar-header">
				<button type="button" id="sidebarCollapse" class="btn btn-info">	<i class="fas fa-align-left"></i>
				</button>
			</div>
			<ul class="list-unstyled components">
				<li class="active">
					<a href="#"> <i class="fas fa-home"></i>
						<span class="nave_name">Home</span>
					</a>
				</li>
				<li>
					<a href="#"> <i class="fas fa-briefcase"></i>
						<span class="nave_name">About</span>
					</a>
				</li>
				<li>
					<a href="#"> <i class="fas fa-copy"></i>
						<span class="nave_name">Pages</span>
					</a>
				</li>
				<li>
					<a href="#"> <i class="fas fa-image"></i>
						<span class="nave_name">Portfolio</span>
					</a>
				</li>
				<li>
					<a href="#"> <i class="fas fa-question"></i>
						<span class="nave_name">FAQ</span>
					</a>
				</li>
				<li>
					<a href="#"> <i class="fas fa-paper-plane"></i>
						<span class="nave_name">Contact</span>
					</a>
				</li>
			</ul>
		</nav>
		<!-- Page Content  -->
		<div id="content">
			<nav class="navbar navbar-expand-lg navbar-light bg-light">
				<div class="container-fluid">
					<button class="btn btn-dark d-inline-block d-lg-none ml-auto" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"> <i class="fas fa-align-justify"></i>
					</button>
					<div class="left_search_icon collapse navbar-collapse">	<span class="search_icon_bg"><i class="fa fa-search" aria-hidden="true"></i></span>
					</div>
					<div class="collapse navbar-collapse" id="navbarSupportedContent">
						<ul class="nav navbar-nav ml-auto">
							<li class="nav-item active"> <a class="nav-link" href="#"><i class="fa fa-plus" aria-hidden="true"></i> Add</a>
							</li>
							<li class="nav-item"> <a class="nav-link" href="#"><i class="fa fa-envelope" aria-hidden="true"></i></a>
							</li>
							<li class="nav-item"> <a class="nav-link" href="#">Name/i></a>
							</li>
							<li class="nav-item"> <a class="nav-link" href="#"><i class="fa fa-user" aria-hidden="true"></i></a>
							</li>
						</ul>
					</div>
				</div>
			</nav>
			<div class="row date_details">
				<div class="col-md-10 mx-auto">
					<div class="row">
						<div class="col-sm-4">	
							<div class="row contact_title_heaer">
								<div class="col-sm-2">
									<i class="fa fa-address-book" aria-hidden="true"></i>
								</div>
								<div class="col-sm-10">
									<h1>Contacts</h1>
									<p>Contact Details</p>
								</div>
							</div>
							<div class="modal fade" id="modalForm" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
								<div class="modal-dialog" role="document">
									<div class="modal-content">
										<!-- Modal Header -->
										<div class="modal-header text-center">
											<h4 class="modal-title w-100 font-weight-bold" id="myModalLabel">Contact Form</h4>
											<button type="button" class="close" data-dismiss="modal"> <span aria-hidden="true">&times;</span>
												<span class="sr-only">Close</span>
											</button>
										</div>
										<!-- Modal Body -->
										<div class="modal-body mx-3">
											<p class="statusMsg"></p>
											<form class="ajax form-inline needs-validation" novalidate>
													<div class="form-group md-form">
														<label for="name">Name:</label>
														<input class="form-control" type="text" name="name" id="name" required>
														
													</div>
													<div class="form-group form-row md-form">
														<label for="email">Email:</label>
														<input class="form-control" type="email" name="email" id="email" required>
													</div>
													<div class="form-group form-row md-form">
														<label for="phone">Phone:</label>
														<input class="form-control" type="number" name="phone" id="phone" required>
													</div>
													<div class="form-group form-row md-form">
														<label for="company">Company:</label>
														<input class="form-control" type="text" name="company" id="company" required>
													</div>
													<div class="form-group form-row md-form">
														<label for="address md-form">Address:</label>
														<textarea class="form-control" name="address" id="address" cols="30" rows="5"></textarea>
													</div>
													<div class="modal-footer">
														<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
														<button type="submit" class="btn btn-primary submitBtn" id="submit_btn">Submit</button>
														<button type="button" id="update_btn" style="display: none;">UPDATE</button>
													</div>
												</form>
										</div>
										<!-- Modal Footer -->
									</div>
								</div>
							</div>
						</div>
						
						<div class="col-sm-8">
							<p><span>Sort By :</span> Data Created <i class="fa fa-caret-down" aria-hidden="true"></i></p>
						</div>
						
					</div>
				</div>
			</div>
			<div class="row list_search_section">
				<div class="col-md-10 mx-auto">
				<div class="row">
					<div class="col-sm-3">
						<div class="active-pink-4 mb-4">
							<input id="myInput" class="form-control" type="text" placeholder="Search" aria-label="Search">
						</div>
					</div>
					<div class="col-sm-6">	
						<button class="btn btn-success btn-lg btn btn-1" data-toggle="modal" data-target="#modalForm"><i class="fa fa-plus" aria-hidden="true"></i> Add Contact</button>
					</div>
					</div>
				</div>
			</div>
			<div class="row contact_list">
				<div class="col-md-10 mx-auto">
					<div class="row">
					<div class="col-sm-6">
						<?php echo $comments; ?>
					</div>
					<div class="col-sm-6">
						<div class="details_all">
							<div class="details_name"><h2>K</h2></div>
							<div class="details_name">Krishnamoorthy</div>
							<div class="row">
								<div class="col-sm-6"><p>Name</p></div>
								<div class="col-sm-6"><p>Krishnamoorthy</p></div>
							</div>
							<div class="row">
								<div class="col-sm-6"><p>Email</p></div>
								<div class="col-sm-6"><p>mkrishnamoorthy352gmail.com</p></div>
							</div>
							<div class="row">
								<div class="col-sm-6"><p>Phone</p></div>
								<div class="col-sm-6"><p>995227951</p></div>
							</div>
							<div class="row">
								<div class="col-sm-6"><p>Company</p></div>
								<div class="col-sm-6"><p>Inxys</p></div>
							</div>
							<div class="row">
								<div class="col-sm-6"><p>Address</p></div>
								<div class="col-sm-6"><p>Chennai</p></div>
							</div>
						</div>
					</div>
					</div>
				</div>
			</div>

		</div>
	</div>
</body>

</html>
<!-- Add JQuery -->
<script src="js/jquery.min.js"></script>
<script src="bootstrap-4.0.0/js/bootstrap.min.js"></script>
<script src="js/scripts.js"></script>

<script type="text/javascript">
	$(document).ready(function () {
		$('#sidebarCollapse').on('click', function () {
			$('#sidebar').toggleClass('active');
		});
	});
</script>