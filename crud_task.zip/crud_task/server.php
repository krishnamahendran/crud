<?php 
  $conn = mysqli_connect('localhost', 'root', '', 'crud_test');
  if (!$conn) {
    die('Connection failed ' . mysqli_error($conn));
  }
  if (isset($_POST['save'])) {
    $name = $_POST['name'];
	$email = $_POST['email'];
	$phone = $_POST['phone'];
	$company = $_POST['company'];
  	$address = $_POST['address'];
  	$sql = "INSERT INTO comments (name, email, phone, company, address) VALUES ('{$name}', '{$email}', '{$phone}', '{$company}', '{$address}')";
  	if (mysqli_query($conn, $sql)) {
  	  $id = mysqli_insert_id($conn);
      $saved_comment = '<div class="comment_box">
      		<div class="row list_group">
		<div class="col-sm-1">
			<div class="add_list_icon"><i class="fa fa-check-square" aria-hidden="true"></i></div>
		</div>	
		<div class="col-sm-5">	
			<div class="display_name">'. $name .'</div>
			<div class="display_email">'. $email .'</div>
		</div>	
		<div class="col-sm-4">	
			<div class="display_company">'. $company .'</div>
		</div>	
		<div class="col-sm-2">	
			<button class="btn btn-success btn-lg edit" data-toggle="modal" data-target="#modalForm" data-id="' . $id . '"><i class="fa fa-edit"></i></button>
			<span class="delete" data-id="' . $id . '" ><i class="fa fa-trash" aria-hidden="true"></i></span>
		</div>	
</div>
<div class="display_phone" style="display: none;">'. $phone .'</div>
<div class="display_address" style="display: none;">'. $address .'</div>
      	</div>';
  	  echo $saved_comment;
  	}else {
  	  echo "Error: ". mysqli_error($conn);
  	}
  	exit();
  }
  // delete comment fromd database
  if (isset($_GET['delete'])) {
  	$id = $_GET['id'];
  	$sql = "DELETE FROM comments WHERE id=" . $id;
  	mysqli_query($conn, $sql);
  	exit();
  }
  if (isset($_POST['update'])) {
  	$id = $_POST['id'];
  	$name = $_POST['name'];
	$email = $_POST['email'];
	$phone = $_POST['phone'];
	$company = $_POST['company'];
  	$address = $_POST['address'];
  	$sql = "UPDATE comments SET name='{$name}', email='{$email}', phone='{$phone}', company='{$company}', address='{$address}' WHERE id=".$id;
  	if (mysqli_query($conn, $sql)) {
  		$id = mysqli_insert_id($conn);
  		$saved_comment = '<div class="comment_box">
  		  <span class="delete" data-id="' . $id . '" ><i class="fa fa-trash" aria-hidden="true"></i></span>
			<button class="btn btn-success btn-lg edit" data-toggle="modal" data-target="#modalForm" data-id="' . $id . '"><i class="fa fa-edit"></i></button>
      		<div class="display_name">'. $name .'</div>
      		<div class="display_email">'. $email .'</div>
			<div class="display_phone">'. $phone .'</div>
      		<div class="display_company">'. $company .'</div>
			<div class="display_address">'. $address .'</div>
  	  </div>';
  	  echo $saved_comment;
  	}else {
  	  echo "Error: ". mysqli_error($conn);
  	}
  	exit();
  }

  // Retrieve comments from database
  $sql = "SELECT * FROM comments";
  $result = mysqli_query($conn, $sql);
  
  $comments = '<div id="display_area"><div class="row list_title_group">
		<div class="col-sm-1">
			<div class="add_list_icon"><i class="fa fa-plus" aria-hidden="true"></i></div>
		</div>	
		<div class="col-sm-5">	
			<div class="list_basic_info">Basic Inof</div>
		</div>	
		<div class="col-sm-4">	
			<div class="list_company_info">Company</div>
		</div>	
		<div class="col-sm-2">	
			<div class="list_action">Action</div>
		</div>
</div>';
    while ($row = mysqli_fetch_array($result)) {
  	$comments .= '<div class="comment_box">
  		  <div class="row list_group">
		<div class="col-sm-1">
			<div class="add_list_icon"><i class="fa fa-check-square" aria-hidden="true"></i></i></div>
		</div>	
		<div class="col-sm-5">	
			<div class="display_name">'. $row['name'] .'</div>
			<div class="display_email">'. $row['email'] .'</div>
		</div>	
		<div class="col-sm-4">	
			<div class="display_company">'. $row['company'] .'</div>
		</div>	
		<div class="col-sm-2">	
			<button class="btn btn-success btn-lg edit" data-toggle="modal" data-target="#modalForm" data-id="' . $row['id'] . '"><i class="fa fa-edit"></i></button> <span class="delete" data-id="' . $row['id'] . '" ><i class="fa fa-trash" aria-hidden="true"></i></span>
		</div>	
</div>
<div class="display_phone" style="display: none;">'. $row['phone'] .'</div>
<div class="display_address" style="display: none;">'. $row['address'] .'</div>
  	  </div>';
  }
  $comments .= '</div>';
?>