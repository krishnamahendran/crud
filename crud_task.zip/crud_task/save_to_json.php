<?php

    if (isset($_POST['firstname']) && isset($_POST['lastname'])) {
        $params = array('firstname' => $_POST['firstname'], 'lastname' => $_POST['lastname']);

        $jsonObject = json_encode($params);
        file_put_contents('my_json_data.json', $jsonObject, FILE_APPEND);
    }
    else {
        echo "Noooooooob";
    }

?>