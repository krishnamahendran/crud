$(document).ready(function(){
  // save comment to database
  $(document).on('click', '#submit_btn', function(){
	var reg = /^[A-Z0-9._%+-]+@([A-Z0-9-]+\.)+[A-Z]{2,4}$/i;
    var name = $('#name').val();
	var email = $('#email').val();
	var phone = $('#phone').val();
	var company = $('#company').val();
	var address = $('#address').val();
	if(name.trim() == '' ){
        alert('Please enter your name.');
        $('#name').focus();
        return false;
    }else if(email.trim() == '' ){
        alert('Please enter your email.');
        $('#email').focus();
        return false;
    }else if(email.trim() != '' && !reg.test(email)){
        alert('Please enter valid email.');
        $('#email').focus();
        return false;
    }else if(phone.trim() == ''){
        alert('Please enter valid phone nmber.');
        $('#phone').focus();
        return false;
    }else if(company.trim() == ''){
        alert('Please enter valid company nmae.');
        $('#company').focus();
        return false;
    }else if(address.trim() == ''){
        alert('Please enter valid Address.');
        $('#address').focus();
        return false;
    }else{
		$.ajax({
		  url: 'server.php',
		  type: 'POST',
		  data: {
			'save': 1,
			'name': name,
			'email': email,
			'phone': phone,
			'company': company,
			'address': address,
		  },
		  success: function(response){
		   $('#name').val('');
			$('#email').val('');
			$('#phone').val('');
			$('#company').val('');
			$('#address').val('');
			$('#display_area').append(response);
		  }
		});
	}
  });
  // delete from database
  $(document).on('click', '.delete', function(){
  	var id = $(this).data('id');
	
	//$(this).parents(".comment_box").find(".add_list_icon").hide();
  	$clicked_btn = $(this);
  	$.ajax({
  	  url: 'server.php',
  	  type: 'GET',
  	  data: {
    	'delete': 1,
    	'id': id,
      },
      success: function(response){
        // remove the deleted comment
        $clicked_btn.parent().remove();
        $('#name').val('');
        $('#email').val('');
		$('#company').val('');
		$(this).parents(".comment_box").find(".add_list_icon").remove();
	  }
  	});
	$(this).parents(".comment_box").find(".add_list_icon").remove();
  });
  var edit_id;
  var $edit_comment;
  $(document).on('click', '.edit', function(){
  	edit_id = $(this).data('id');
  	$edit_comment = $(this).parent();
  	// grab the comment to be editted
  	var name = $(this).siblings('.display_name').text();
  	var email = $(this).siblings('.display_email').text();
	var phone = $(this).siblings('.display_phone').text();
	var company = $(this).siblings('.display_company').text();
	var address = $(this).siblings('.display_address').text();
  	// place comment in form
  	$('#name').val(name);
  	$('#email').val(email);
	$('#phone').val(phone);
	$('#company').val(company);
	$('#address').val(address);
  	$('#submit_btn').hide();
  	$('#update_btn').show();
  });
  $(document).on('click', '.display_name', function(){
  	edit_id = $(this).data('id');
  	$edit_comment = $(this).parent();
  	// grab the comment to be editted
  	var name = $(this).text();
  	var email = $(this).siblings('.display_email').text();
	var phone = $(this).siblings('.display_phone').text();
	var company = $(this).siblings('.display_company').text();
	var address = $(this).siblings('.display_address').text();
  	$(".contact_details_show").append("<div class='newData'>" +
                      "<div class='infoBox'>" +
                        name + 
                      "</div>" +
                   "</div>");
  });
  $(document).on('click', '#update_btn', function(){
  	var id = edit_id;
  	var name = $('#name').val();
	var email = $('#email').val();
	var phone = $('#phone').val();
	var company = $('#company').val();
	var address = $('#address').val();
  	$.ajax({
      url: 'server.php',
      type: 'POST',
      data: {
      	'update': 1,
      	'id': id,
      	'name': name,
      	'email': email,
		'phone': phone,
		'company': company,
		'address': address,
      },
      success: function(response){
      	$('#name').val('');
      	$('#email').val('');
		$('#phone').val('');
		$('#company').val('');
		$('#address').val('');
      	$('#submit_btn').show();
      	$('#update_btn').hide();
      	$edit_comment.replaceWith(response);
      }
  	});		
  });
  $("#myInput").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#display_area .comment_box").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});